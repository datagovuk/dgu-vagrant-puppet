# -*- coding: utf-8 -*-
# Copyright (c) 2011-2013 Raphaël Barrois

from .test_base import *
from .test_containers import *
from .test_declarations import *
from .test_django import *
from .test_fuzzy import *
from .test_using import *
from .test_utils import *
from .test_alchemy import *
