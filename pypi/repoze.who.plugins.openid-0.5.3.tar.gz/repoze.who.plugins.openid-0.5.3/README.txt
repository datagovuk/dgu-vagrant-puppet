Introduction
============

``repoze.who.plugins.openid`` is a plugin for the `repoze.who framework <http://static.repoze.org/whodocs/>`_
enabling `OpenID <http://openid.net>`_ logins.

For more information read the `documentation <http://quantumcore.org/docs/repoze.who.plugins.openid>`_ 
or check out the `source code <http://code.google.com/p/repozeopenid/>`_.


