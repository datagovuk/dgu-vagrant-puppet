Installation of the plugin
==========================

To install the plugin all you have to do is to use ``easy_install``::

    easy_install repoze.who.plugins.openid

This will install the plugin with all it's dependencies (like the OpenID library).

If you use buildout you can simply add ``repoze.who.plugins.openid`` to the list
of Python eggs to install.




