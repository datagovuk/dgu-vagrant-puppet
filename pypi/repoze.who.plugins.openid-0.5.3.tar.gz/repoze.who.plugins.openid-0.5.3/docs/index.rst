.. repoze.who openid plugin documentation master file, created by sphinx-quickstart on Sat Nov  1 11:43:55 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to repoze.who openid plugin's documentation!
====================================================

Contents:

.. toctree::
   :maxdepth: 2

   installation
   basicflow
   usage
   api/identification

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

