#: E101 W191
for a in 'abc':
    for b in 'xyz':
        print a  # indented with 8 spaces
	print b  # indented with 1 tab
