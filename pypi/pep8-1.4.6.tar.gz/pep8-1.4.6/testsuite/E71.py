#: E712
if res == True:
    pass
#: E712
if res != False:
    pass
#: E711
if res == None:
    pass
