:mod:`webhelpers.html.render`
================================================

.. automodule:: webhelpers.html.render

.. currentmodule:: webhelpers.html.render

.. autofunction:: render

.. autofunction:: sanitize
