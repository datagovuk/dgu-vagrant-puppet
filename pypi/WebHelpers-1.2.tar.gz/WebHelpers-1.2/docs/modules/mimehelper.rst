:mod:`webhelpers.mimehelper`
================================================

.. automodule:: webhelpers.mimehelper

.. currentmodule:: webhelpers.mimehelper

.. autoclass:: MIMETypes
    :members:
    :undoc-members:
