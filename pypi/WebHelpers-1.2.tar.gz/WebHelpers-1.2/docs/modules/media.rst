:mod:`webhelpers.media`
================================================

.. automodule:: webhelpers.media

.. currentmodule:: webhelpers.media

.. autofunction:: choose_height
.. autofunction:: get_dimensions_pil
.. autofunction:: get_dimensions
