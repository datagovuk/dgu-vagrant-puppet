:mod:`webhelpers.pylonslib.minify`
================================================

.. automodule:: webhelpers.pylonslib.minify

.. currentmodule:: webhelpers.pylonslib.minify

.. autofunction:: javascript_link

.. autofunction:: stylesheet_link
