:mod:`webhelpers.pylonslib.flash`
================================================

.. automodule:: webhelpers.pylonslib.flash

.. currentmodule:: webhelpers.pylonslib.flash

Classes
-------

.. autoclass:: Flash
   :members: __call__, pop_messages

.. autoclass:: Message
   :members:
