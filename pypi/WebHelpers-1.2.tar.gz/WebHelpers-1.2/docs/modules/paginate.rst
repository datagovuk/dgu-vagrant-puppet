:mod:`webhelpers.paginate`
================================================

.. automodule:: webhelpers.paginate

.. currentmodule:: webhelpers.paginate

Page Objects
------------

.. autoclass:: Page
    :members:
    :undoc-members:
