===========================
 API Reference
===========================

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 2
   
    carrot.connection 
    carrot.messaging
    carrot.backends
    carrot.backends.base
    carrot.backends.pyamqplib
    carrot.backends.pikachu
    carrot.backends.pystomp
    carrot.backends.queue
    carrot.serialization
    carrot.utils
