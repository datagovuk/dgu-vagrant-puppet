import doctest

if __name__ == '__main__':
    doctest.testfile('proxy_example.txt', optionflags=doctest.ELLIPSIS)
    
