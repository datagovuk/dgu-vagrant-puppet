Fanstatic: Resource publishing for Pythonistas
==============================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   quickstart
   concepts
   library
   optimization
   configuration
   paste_deploy
   serf
   api
   libraries
   integration
   community
   development

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

