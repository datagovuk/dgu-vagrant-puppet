Community
=========

.. _`mailing list`:

Mailing list
------------

Please talk to us on the Fanstatic mailing list:
fanstatic@googlegroups.com

You can subscribe here: https://groups.google.com/group/fanstatic

You can also participate in the discussions through the Gmane_ group:
`gmane.comp.python.wsgi.fanstatic`_

.. _`gmane.comp.python.wsgi.fanstatic`: http://dir.gmane.org/gmane.comp.python.wsgi.fanstatic

.. _gmane: http://gmane.org

IRC
---

Come to the ``#fanstatic`` IRC channel on FreeNode_.

.. _FreeNode: http://freenode.net/


