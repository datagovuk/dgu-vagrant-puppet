===================================
 celery.app.task
===================================

.. contents::
    :local:
.. currentmodule:: celery.app.task

.. automodule:: celery.app.task
    :members: Context, TaskType, BaseTask
