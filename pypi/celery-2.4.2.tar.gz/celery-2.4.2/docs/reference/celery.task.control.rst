====================================================
 celery.task.control
====================================================

.. contents::
    :local:
.. currentmodule:: celery.task.control

.. automodule:: celery.task.control
    :members:
    :undoc-members:
