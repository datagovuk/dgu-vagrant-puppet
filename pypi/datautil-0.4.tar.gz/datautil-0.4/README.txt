Swiss Army Knife for Data Work.

For details read the main package docstring.

Open source software licensed under the MIT license.

## Install

1. Install setuptools

2. Either install directy from PyPI usinging easy_install:
  
    $ easy_install swiss

   OR install from the source obtaintable from the mercurial repository:

    $ hg clone https://knowledgeforge.net/okfn/swiss
 
