# left here for backwards compatibility 2011-01-04
from swiss import *
