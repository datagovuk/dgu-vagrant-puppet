'''OFS. See README.rst.'''
import base
from base import OFSException
from factory import get_impl
