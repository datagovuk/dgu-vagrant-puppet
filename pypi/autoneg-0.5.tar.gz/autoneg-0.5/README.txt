Simple HTTP Content Autonegotiation
