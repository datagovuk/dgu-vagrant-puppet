{
    "mime_types": [
        ("text/plain", ["txt", "rst"]),
        ("text/html", ["html"]),
        ("application/rdf+xml", ["rdf", "owl"]),
        ("text/n3", ["n3"])
        ]
}
