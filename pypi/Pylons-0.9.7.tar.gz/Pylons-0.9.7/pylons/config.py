"""Deprecated: The pylons.config module has moved to pylons.configuration"""
from pylons.configuration import *
